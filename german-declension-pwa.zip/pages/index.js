import React, { useEffect, useMemo, useState } from 'react';
import TopBar from '../components/TopBar';
import QuestionCard from '../components/QuestionCard';
import { generateQuestions } from '../lib/questions';

const STORAGE_KEY = "declension_v1_state";

export default function Home(){
  const [questions, setQuestions] = useState([]);
  const [state, setState] = useState({
    index: 0, totalAttempts: 0, streak: 0, highScore: 0, shuffledIds: []
  });
  const [isReady, setReady] = useState(false);

  useEffect(()=>{
    const q = generateQuestions(12345, 1001);
    setQuestions(q);
    try{
      const raw = localStorage.getItem(STORAGE_KEY);
      if(raw){
        const parsed = JSON.parse(raw);
        setState(parsed);
      } else {
        const shuffledIds = q.map(x=>x.id);
        const s = {...state, shuffledIds};
        setState(s);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
      }
    }catch(e){ console.error(e); }
    setReady(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[]);

  const currentQuestion = useMemo(()=>{
    if(!questions.length || !state.shuffledIds.length) return null;
    const id = state.shuffledIds[state.index % state.shuffledIds.length];
    return questions.find(q => q.id === id) ?? null;
  },[questions, state.index, state.shuffledIds]);

  function persist(s){
    setState(s);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
  }

  function handleAnswer(correct){
    const nextIndex = state.index + 1;
    const totalAttempts = state.totalAttempts + 1;
    const streak = correct ? state.streak + 1 : 0;
    const highScore = Math.max(state.highScore, streak);
    const newState = {...state, index: nextIndex, totalAttempts, streak, highScore};
    persist(newState);
  }

  function shuffleAgain(){
    const arr = [...state.shuffledIds];
    for(let i=arr.length-1;i>0;i--){
      const j = Math.floor(Math.random()*(i+1));
      [arr[i],arr[j]] = [arr[j],arr[i]];
    }
    const newState = {...state, shuffledIds:arr, index:0};
    persist(newState);
  }

  if(!isReady) return <div className="container"><div style={{padding:24}}>Loading…</div></div>

  return (
    <div className="app-shell">
      <div className="container">
        <TopBar total={state.totalAttempts} streak={state.streak} high={state.highScore} />
        <main className="main">
          {currentQuestion ? (
            <QuestionCard q={currentQuestion} onAnswer={handleAnswer} />
          ) : (
            <div className="card">No question available</div>
          )}

          <div style={{display:'flex',gap:8,justifyContent:'space-between'}}>
            <button className="btn" onClick={shuffleAgain}>Shuffle</button>
            <button className="btn" onClick={()=>{
              const newState = {...state, index:0, totalAttempts:0, streak:0};
              persist(newState);
            }}>Reset Progress</button>
          </div>

        </main>

        <div className="footer">Works offline after first load — install to home screen for best experience.</div>
      </div>
    </div>
  );
}
