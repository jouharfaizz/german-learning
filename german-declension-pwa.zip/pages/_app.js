import '../styles/globals.css'
import Head from 'next/head'

function App({ Component, pageProps }) {
  return (
    <>
      <Head>
        <meta name="theme-color" content="#0b61d6" />
        <link rel="manifest" href="/manifest.json" />
        <link rel="icon" href="/icons/icon-192.png" />
      </Head>
      <Component {...pageProps} />
    </>
  )
}

export default App;
