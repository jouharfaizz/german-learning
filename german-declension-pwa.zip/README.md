# German Declension PWA

Mobile-first React PWA for practicing German adjective declension.

## Quick start

1. unzip and run:
```bash
npm install
npm run build
npm start
```

2. Deploy: push to GitHub and connect the repo on Vercel (Next.js autodetected). After deploy, open the Vercel URL on your phone and "Add to Home Screen".

## Notes
- This project generates 1001 questions deterministically.
- Uses `next-pwa` for offline support.
- Replace `public/icons/*` with nicer icons if you want.
