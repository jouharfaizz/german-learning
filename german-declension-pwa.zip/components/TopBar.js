import React from 'react';
export default function TopBar({ total, streak, high }) {
  return (
    <div className="topbar">
      <div style={{display:'flex',alignItems:'center',gap:12}}>
        <div className="title">German Declension</div>
        <div style={{fontSize:13,color:'#0b61d6'}}>Mobile-first PWA</div>
      </div>
      <div className="stats" aria-live="polite">
        <div className="stat-value"><div style={{fontSize:12}}>Total</div><div>{total}</div></div>
        <div className="stat-value"><div style={{fontSize:12}}>Streak</div><div>{streak}</div></div>
        <div className="stat-value"><div style={{fontSize:12}}>High</div><div>{high}</div></div>
      </div>
    </div>
  );
}
