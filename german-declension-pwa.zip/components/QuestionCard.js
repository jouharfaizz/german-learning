import React, { useState } from 'react';
export default function QuestionCard({ q, onAnswer }) {
  const [selected, setSelected] = useState(null);
  const [revealed, setRevealed] = useState(false);

  function makeChoices() {
    const correct = q.correctForm;
    const variations = new Set([correct]);
    const parts = correct.split(" ");
    for(let i=0;i<4 && variations.size<4;i++){
      const pick = Math.random();
      if(pick<0.33){
        variations.add(correct.replace(/([aeiouäöüß]+)n\b/,'$1e'));
      } else if (pick<0.66) {
        variations.add(parts.slice(1).join(" "));
      } else {
        variations.add(correct.replace(/^[^\s]+/, 'schön'));
      }
    }
    const arr = Array.from(variations);
    for(let i=arr.length-1;i>0;i--){
      const j = Math.floor(Math.random()*(i+1));
      [arr[i],arr[j]] = [arr[j],arr[i]];
    }
    return arr.slice(0,4);
  }

  const choices = makeChoices();

  function handleClick(choice){
    setSelected(choice);
    const correct = choice === q.correctForm;
    setRevealed(true);
    onAnswer(correct);
  }

  return (
    <div className="card" role="region" aria-labelledby={`q-${q.id}`}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <div id={`q-${q.id}`} className="qtext">{q.germanBase} + {q.noun}</div>
        <div style={{fontSize:12,color:'#0b61d6',fontWeight:700}}>
          {q.gender}
          {q.withoutArticle ? <span className="badge">no article — case: {q.case}</span> : <span style={{marginLeft:8}} className="badge">{q.case}</span>}
        </div>
      </div>

      <div className="meta">{q.englishHint}</div>

      <div className="options" style={{marginTop:12}}>
        {choices.map(c => {
          const isCorrect = c === q.correctForm;
          const stateClass = revealed ? (isCorrect ? "btn correct" : (c === selected ? "btn wrong" : "btn")) : "btn";
          return (
            <button key={c} className={stateClass} onClick={()=>handleClick(c)} disabled={revealed}>
              {c}
            </button>
          );
        })}
      </div>
      <div className="meta">Pick the full correct phrase. Correct answer shown after selection.</div>
    </div>
  );
}
